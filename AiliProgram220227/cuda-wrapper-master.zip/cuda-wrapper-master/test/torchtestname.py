import torch
torch.cuda.get_device_name(0)
